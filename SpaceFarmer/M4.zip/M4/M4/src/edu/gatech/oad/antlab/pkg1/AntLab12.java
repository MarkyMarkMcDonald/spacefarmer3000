package edu.gatech.oad.antlab.pkg1;



/** 
 * CS2335 Ant Lab
 *
 * AntLab12.java helper class
 */
 public class AntLab12 {
    
    
   /**
    * retrieves a pre-stored string message 
    * @return the string
    */
    public String getMessage() {
        return " You";
    }
    
 } 